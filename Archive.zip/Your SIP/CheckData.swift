//
//  Calculations.swift
//  Passive Money
//
//  Created by Максим Окунеев on 12/13/19.
//  Copyright © 2019 Максим Окунеев. All rights reserved.
//

import UIKit

protocol AlertWrongData {
    func alertWrongData()
}

class CheckData: DataPr {
    

    let limits = Limits()
    var delegate: AlertWrongData?
    
   
    func plusMinusElement(sign: String) -> Int {
        
        if sign == "+" {
            return 1
        } else if sign == "-" {
            return -1
        }
        return 0
    }
    
    func stringToInt(str:String) -> (Int) {
      
        if str == "" {
            return 0
        } else if (str.last == "%" || str.last == "$"){
            return  (Int(str.dropLast())!)
        }
        else {
            return (Int(str)!)
        }
    }
    

    
    func fullCheck(identifier: String, number: String, sign: String) -> Int {
        
        print("id \(identifier) numb \(number) sing \(sign)")
        
        let correctNumber = stringToInt(str: number)
        var action = 0
        
        if sign == "" {
            action = 0
        } else {
            action = plusMinusElement(sign: sign)
        }
        
        if identifier == "sum" {
            action = action * 100
        }

        if limits.checkMinMax(identifier: identifier, number: correctNumber) == false {
            delegate!.alertWrongData()
            return -1
        }
    
        let res = correctNumber + action
    
        return res
    }
    
    func separatedNumber(_ number: Any) -> String {
            guard let itIsANumber = number as? NSNumber else { return "Not a number" }
            let formatter = NumberFormatter()
            formatter.numberStyle = .decimal
            formatter.groupingSeparator = " "
        
            return formatter.string(from: itIsANumber)!
        }
        
        func calculate(age: String, retirementAge: String, sum: String, percent: String) -> (String) {

            var i = 0
            let ageInt = stringToInt(str: age)
            let retirementAgeInt = stringToInt(str: retirementAge)
            let sumInt = stringToInt(str: sum)
            let percentInt = stringToInt(str: percent)
            
            let realPersent = (pow(1 + (Double(percentInt) / 100.0), 1.0/12.0) - 1) * 100
            var result = 0.0

            while i <= (retirementAgeInt - ageInt) * 12 - 1 {
                result = (result + Double(sumInt) ) * (1 + realPersent / 100)
                i = i + 1
            }
            
            return  "\(separatedNumber(Int(result))) $"
        }
    }



