//
//  Limits.swift
//  Your SIP
//
//  Created by Максим Окунеев on 1/25/20.
//  Copyright © 2020 Максим Окунеев. All rights reserved.
//

import UIKit

struct Limits {
    
    let ageMin = 5
    let ageMax = 100
    let retAgeMin = 20
    let retAgeMax = 115
    let sumMin = 10
    let sumMax = 100000
    let percentMin = 0
    let percentMax = 100
    
//    let standartAge = 27
//    let standartRetirementAge = 50
//    let standartSum = 100
//    let standartPercent = 5
    
    func checkMinMax (identifier: String, number: Int) -> Bool {
        
        switch identifier {
        case "age":
            if ((number < ageMin) || (number > ageMax)) {
                return false
            } else {
                return true
            }
        case "retirementAge":
            if ((number < retAgeMin) || (number > retAgeMax)) {
                return false
            } else {
                return true
            }
         case "sum":
            if ((number < sumMin) || (number > sumMax)) {
                return false
            } else {
                return true
            }
          case "percent":
            if ((number < percentMin) || (number > percentMax)) {
                return false
            } else {
                return true
            }
          
        default:
            return false
        }
    }
    
}
    

